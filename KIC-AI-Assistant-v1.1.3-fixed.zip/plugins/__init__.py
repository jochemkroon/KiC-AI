import pcbnew
import wx
import os
import sys

# Voeg de plugin directory toe aan sys.path voor imports
plugin_dir = os.path.dirname(os.path.abspath(__file__))
if plugin_dir not in sys.path:
    sys.path.insert(0, plugin_dir)

class KicAIAssistant(pcbnew.ActionPlugin):
    """
    KIC-AI Assistant Plugin voor KiCad
    AI-powered PCB design assistant met Ollama integratie
    """
    
    def __init__(self):
        super().__init__()
        self.name = "KIC-AI Assistant" 
        self.category = "AI Tools"
        self.description = "AI PCB design assistant with Ollama"
        self.pcbnew_icon_support = hasattr(self, "show_toolbar_button")
        self.show_toolbar_button = True
        self.icon_file_name = os.path.join(os.path.dirname(__file__), "robot_icon.png")
        self.dark_icon_file_name = os.path.join(os.path.dirname(__file__), "robot_icon.png")
        
    def defaults(self):
        pass  # Niet meer nodig met __init__ implementatie
        
    def Run(self):
        """Start the AI Assistant dialog"""
        try:
            # Import de dialog class
            from ai_dialog import AIAssistantDialog
            
            # Maak en toon dialog
            dialog = AIAssistantDialog(None)
            dialog.Show()
            
        except ImportError as e:
            wx.MessageBox(
                f"Cannot load AI dialog:\n{str(e)}\n\nPlease check plugin installation.",
                "KIC-AI Error",
                wx.OK | wx.ICON_ERROR
            )
        except Exception as e:
            wx.MessageBox(
                f"KIC-AI error:\n{str(e)}",
                "KIC-AI Error", 
                wx.OK | wx.ICON_ERROR
            )

# Registreer de plugin
KicAIAssistant().register()
