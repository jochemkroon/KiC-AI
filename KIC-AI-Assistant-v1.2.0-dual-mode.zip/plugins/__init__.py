import pcbnew
import wx
import os
import sys

# Try to import eeschema for schematic support
try:
    import eeschema
    EESCHEMA_AVAILABLE = True
except ImportError:
    EESCHEMA_AVAILABLE = False

# Add plugin directory to sys.path for imports
plugin_dir = os.path.dirname(os.path.abspath(__file__))
if plugin_dir not in sys.path:
    sys.path.insert(0, plugin_dir)

class KicAIAssistant(pcbnew.ActionPlugin):
    """
    KIC-AI Assistant Plugin voor KiCad
    AI-powered PCB design assistant met Ollama integratie
    """
    
    def __init__(self):
        super().__init__()
        self.name = "KIC-AI Assistant" 
        self.category = "AI Tools"
        self.description = "AI PCB design assistant with Ollama"
        self.pcbnew_icon_support = hasattr(self, "show_toolbar_button")
        self.show_toolbar_button = True
        self.icon_file_name = os.path.join(os.path.dirname(__file__), "robot_icon.png")
        self.dark_icon_file_name = os.path.join(os.path.dirname(__file__), "robot_icon.png")
        
    def defaults(self):
        pass  # Niet meer nodig met __init__ implementatie
        
    def Run(self):
        """Start the AI Assistant dialog"""
        try:
            # Import de dialog class
            from ai_dialog import AIAssistantDialog
            
            # Determine context - check if we're in PCB or Schematic editor
            context_type = "pcb"  # Default to PCB
            
            # Better context detection
            try:
                # Check if we have a board loaded and it has a valid filename
                board = pcbnew.GetBoard()
                if board and board.GetFileName():
                    # We have a PCB board loaded
                    context_type = "pcb"
                    
                    # Check if board is mostly empty (might indicate schematic mode)
                    footprints = list(board.GetFootprints())
                    if len(footprints) == 0:
                        # No components on PCB, might be in schematic mode
                        # Ask user what they want to analyze
                        dlg = wx.MessageDialog(
                            None,
                            "What would you like to analyze?\n\nNote: Component data comes from the PCB board.",
                            "KIC-AI Context Selection",
                            wx.YES_NO | wx.ICON_QUESTION
                        )
                        dlg.SetYesNoLabels("Schematic/Circuit", "PCB Layout")
                        result = dlg.ShowModal()
                        dlg.Destroy()
                        
                        context_type = "schematic" if result == wx.ID_YES else "pcb"
                else:
                    # No board loaded - default to schematic mode
                    context_type = "schematic"
                    
            except Exception as e:
                # Fallback to PCB mode
                context_type = "pcb"
            
            # Create and show dialog with detected context
            dialog = AIAssistantDialog(None, context_type=context_type)
            dialog.Show()
            
        except ImportError as e:
            wx.MessageBox(
                f"Cannot load AI dialog:\n{str(e)}\n\nPlease check plugin installation.",
                "KIC-AI Error",
                wx.OK | wx.ICON_ERROR
            )
        except Exception as e:
            wx.MessageBox(
                f"KIC-AI error:\n{str(e)}",
                "KIC-AI Error", 
                wx.OK | wx.ICON_ERROR
            )

# Registreer de plugin
KicAIAssistant().register()
