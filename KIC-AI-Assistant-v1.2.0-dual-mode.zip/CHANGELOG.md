# Chang## [1.2.0] - 2025-07-30

### Major Features Added
- **Dual Mode Support**: Plugin now works in both PCB Editor (pcbnew) and Schematic Editor (eeschema)
- **Context-Aware Interface**: Automatically detects whether you're working on PCB layout or schematic design
- **Schematic Analysis**: Complete circuit analysis with component grouping, value analysis, and net connectivity
- **Smart Context Detection**: Auto-detects editor context or asks user when ambiguous

### New Schematic Capabilities
- Circuit component analysis grouped by type (R, C, L, U, etc.)
- Net connectivity analysis for schematic review
- Component value and footprint validation
- Circuit topology insights and design recommendations
- Schematic-specific AI prompts and responses

### Enhanced User Experience
- Dynamic button labels: "Analyze PCB" or "Analyze Schematic" based on context
- Context-specific welcome messages and capabilities
- Improved AI prompts tailored for PCB vs Schematic analysis
- Better error handling for different editor contexts

### Technical Improvements
- Dual-context architecture supporting both PCB and schematic workflows
- Enhanced AI system prompts for circuit design vs PCB layout advice
- Improved component data collection for schematic analysis
- Better integration with KiCad's design data structures

## [1.1.3] - 2025-07-30

### Fixed
- Plugin icon now displays correctly in KiCad toolbar using Fabrication Toolkit pattern
- Implemented proper icon support with both icon_file_name and dark_icon_file_name
- Fixed ActionPlugin initialization following KiCad best practices
- All UI text and comments now in English for consistency

### Improved  
- Plugin initialization follows established KiCad plugin patterns
- Better icon handling for both light and dark themes
- Cleaner codebase with English documentation

## [1.1.2] - 2025-07-30

### Added
- Robot icon for better toolbar appearance
- Detailed component analysis with specific component information
- Enhanced AI context with full PCB data for every user question
- Specific component lookup capabilities (e.g., asking about "R1" or specific resistors)

### Improved
- AI now provides specific answers referencing actual component values and positions
- Better PCB context integration for targeted component questions
- Increased context window for more detailed analysis
- Enhanced conversation memory with PCB awareness

### Fixed
- Plugin icon now displays properly in KiCad toolbar
- AI responses now reference specific components instead of giving generic answers

## [1.1.1] - 2025-07-30log

All notable changes to the KIC-AI Assistant plugin will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] - 2025-07-30

### Added
- **Conversation Memory**: AI now remembers previous messages in the conversation
- **Context Management**: Maintains last 20 messages for contextual responses
- **Show Context Button**: View what the AI remembers from your conversation
- **Improved Prompting**: Enhanced system prompts for better context awareness
- **Larger Context Window**: Increased to 4096 tokens for longer conversations

### Changed
- **Enhanced AI Responses**: AI can now reference previous questions and build upon earlier discussions
- **Better Context Handling**: PCB analysis results are included in conversation context
- **Improved Welcome Message**: Updated to explain conversation memory feature

### Fixed
- **Conversation Continuity**: AI no longer treats each message as isolated
- **Memory Management**: Automatic cleanup of old messages to prevent memory issues

## [1.0.0] - 2025-07-29

### Added
- Initial release of KIC-AI Assistant
- AI-powered chat interface for PCB design assistance
- Automatic PCB analysis functionality
- Ollama integration with llama3.2:3b model
- Real-time design advice and suggestions
- English interface with larger, readable fonts
- Support for KiCad 6.0+
- Component analysis and statistics
- Net and track information display
- Board dimension reporting
- Design best practices recommendations

### Features
- **Chat Interface**: Interactive dialog for asking PCB design questions
- **PCB Analysis**: Click-button analysis of current PCB design
- **AI Responses**: Context-aware responses using local LLM
- **Privacy-First**: All AI processing happens locally via Ollama
- **User-Friendly**: Large fonts and clear English interface

### Requirements
- KiCad 6.0 or higher
- Python 3.7+
- Ollama with llama3.2:3b model
- requests Python package

### Installation
- Plugin installable via KiCad Plugin and Content Manager
- Also supports manual installation
