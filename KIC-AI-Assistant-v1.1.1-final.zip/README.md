# KIC-AI Assistant

AI-powered PCB design assistant plugin for KiCad with Ollama integration.

![KiCad Plugin](https://img.shields.io/badge/KiCad-Plugin-blue)
![AI Powered](https://img.shields.io/badge/AI-Powered-green)
![Ollama](https://img.shields.io/badge/Ollama-Integration-orange)

## 🤖 Features

- **AI Chat Interface**: Interactive dialog for PCB design assistance
- **PCB Analysis**: Automatic analysis of your PCB design with detailed insights
- **Design Advice**: Get practical suggestions for component placement, routing, and best practices
- **Local LLM**: Uses Ollama for privacy-focused AI processing
- **Real-time Help**: Ask questions about your PCB design and get instant answers

## 📋 Requirements

- **KiCad 6.0+**
- **Python 3.7+**
- **Ollama** with `llama3.2:3b` model
- **requests** Python package

## 🚀 Installation

### Method 1: KiCad Plugin Manager (Recommended)

1. Download the latest release ZIP file
2. Open KiCad → **Plugin and Content Manager**
3. Click **Install from File**
4. Select the downloaded ZIP file
5. Restart KiCad

### Method 2: Manual Installation

1. Download and extract the plugin
2. Copy to your KiCad plugins directory:
   - **Windows**: `%APPDATA%/kicad/6.0/scripting/plugins/`
   - **macOS**: `~/Library/Application Support/kicad/6.0/scripting/plugins/`
   - **Linux**: `~/.config/kicad/6.0/scripting/plugins/`

## 🔧 Setup

### 1. Install Ollama

Download and install Ollama from [ollama.ai](https://ollama.ai)

### 2. Install AI Model

```bash
ollama pull llama3.2:3b
```

### 3. Start Ollama Server

```bash
ollama serve
```

## 💡 Usage

1. **Open KiCad PCB Editor** with your PCB design
2. **Click the KIC-AI Assistant button** in the toolbar
3. **Choose an option**:
   - Click **"Analyze PCB"** for automatic analysis
   - Type a question in the chat input
   - Get AI-powered design advice and suggestions

### Example Questions

- "How can I improve the routing on this PCB?"
- "Are there any potential EMI issues?"
- "What's the best way to place these components?"
- "Can you review my power distribution?"

## 🖼️ Screenshots

### Main Interface
The AI Assistant provides an intuitive chat interface with PCB analysis capabilities.

### PCB Analysis
Automatic analysis provides:
- Component count and types
- Board dimensions
- Net and track statistics
- Layer information
- Design recommendations

## 🛠️ Development

### Project Structure

```
KIC-AI-Assistant/
├── metadata.json          # KiCad plugin metadata
├── plugins/
│   ├── __init__.py        # Main plugin entry point
│   ├── ai_dialog.py       # AI chat dialog interface
│   └── icon.png           # Plugin icon
├── README.md
├── LICENSE
└── .gitignore
```

### Building

To create a release ZIP:

```bash
zip -r kic-ai-assistant.zip metadata.json plugins/ -x "*.pyc" "*__pycache__*"
```

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the project
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **KiCad** team for the excellent PCB design software
- **Ollama** team for local LLM capabilities
- **Meta** for the Llama model

## 📞 Support

If you encounter any issues or have questions:

1. Check the [Issues](../../issues) page
2. Create a new issue with detailed information
3. Include your KiCad version and error messages

## 🔄 Changelog

### v1.0.0
- Initial release
- AI chat interface
- PCB analysis functionality
- Ollama integration
- English interface with larger fonts

---

**Made with ❤️ for the KiCad community**
