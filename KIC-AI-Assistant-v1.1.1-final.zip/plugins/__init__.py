import pcbnew
import wx
import os
import sys

# Voeg de plugin directory toe aan sys.path voor imports
plugin_dir = os.path.dirname(os.path.abspath(__file__))
if plugin_dir not in sys.path:
    sys.path.insert(0, plugin_dir)

class KicAIAssistant(pcbnew.ActionPlugin):
    """
    KIC-AI Assistant Plugin voor KiCad
    AI-powered PCB design assistant met Ollama integratie
    """
    
    def defaults(self):
        self.name = "KIC-AI Assistant"
        self.category = "AI Tools"
        self.description = "AI PCB design assistant with Ollama"
        self.show_toolbar_button = True
        # Geen icon_file_name - gebruik standaard KiCad icon
        
    def Run(self):
        """Start the AI Assistant dialog"""
        try:
            # Import de dialog class
            from ai_dialog import AIAssistantDialog
            
            # Maak en toon dialog
            dialog = AIAssistantDialog(None)
            dialog.Show()
            
        except ImportError as e:
            wx.MessageBox(
                f"Cannot load AI dialog:\n{str(e)}\n\nPlease check plugin installation.",
                "KIC-AI Error",
                wx.OK | wx.ICON_ERROR
            )
        except Exception as e:
            wx.MessageBox(
                f"KIC-AI error:\n{str(e)}",
                "KIC-AI Error", 
                wx.OK | wx.ICON_ERROR
            )

# Registreer de plugin
KicAIAssistant().register()
