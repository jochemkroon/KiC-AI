import wx
import pcbnew
import threading
import json

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False

class AIAssistantDialog(wx.Frame):
    """AI Assistant Dialog voor PCB design hulp"""
    
    def __init__(self, parent):
        super().__init__(parent, title="KIC-AI Assistant", size=(800, 600))
        
        # Icon instellen (optioneel)
        self.SetIcon(wx.Icon())
        
        # Chat history voor context
        self.conversation_history = []
        
        # UI opzetten
        self.init_ui()
        
        # Centreer op scherm
        self.CenterOnScreen()
        
        # Welkom bericht
        self.add_message("🤖 KIC-AI", 
                        "Welcome to KIC-AI Assistant!\n\n"
                        "I can help you with:\n"
                        "• PCB analysis and advice\n"
                        "• Design review and tips\n" 
                        "• Component placement advice\n"
                        "• Routing suggestions\n\n"
                        "💡 I remember our conversation!\n"
                        "Try asking: 'My name is John' then 'What's my name?'\n\n"
                        "Let's start designing!")
        
    def init_ui(self):
        """Initialiseer de user interface"""
        panel = wx.Panel(self)
        
        # Main sizer
        main_sizer = wx.BoxSizer(wx.VERTICAL)
        
        # Chat area
        self.chat_ctrl = wx.TextCtrl(
            panel, 
            style=wx.TE_MULTILINE | wx.TE_READONLY | wx.TE_WORDWRAP
        )
        self.chat_ctrl.SetFont(wx.Font(14, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL))
        
        # Input area
        input_sizer = wx.BoxSizer(wx.HORIZONTAL)
        
        self.input_ctrl = wx.TextCtrl(panel, style=wx.TE_PROCESS_ENTER)
        self.input_ctrl.SetFont(wx.Font(12, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL))
        self.input_ctrl.SetHint("Type your question here...")
        
        # Buttons
        self.send_btn = wx.Button(panel, label="Send")
        self.analyze_btn = wx.Button(panel, label="Analyze PCB")
        self.clear_btn = wx.Button(panel, label="Clear Chat")
        self.context_btn = wx.Button(panel, label="Show Context")
        
        # Input layout
        input_sizer.Add(self.input_ctrl, 1, wx.EXPAND | wx.RIGHT, 5)
        input_sizer.Add(self.send_btn, 0, wx.RIGHT, 5)
        input_sizer.Add(self.analyze_btn, 0, wx.RIGHT, 5) 
        input_sizer.Add(self.clear_btn, 0, wx.RIGHT, 5)
        input_sizer.Add(self.context_btn, 0)
        
        # Status bar
        self.status_text = wx.StaticText(panel, label="Ready")
        self.status_text.SetFont(wx.Font(10, wx.FONTFAMILY_DEFAULT, wx.FONTSTYLE_ITALIC, wx.FONTWEIGHT_NORMAL))
        
        # Main layout
        main_sizer.Add(self.chat_ctrl, 1, wx.EXPAND | wx.ALL, 10)
        main_sizer.Add(input_sizer, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)
        main_sizer.Add(self.status_text, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 10)
        
        panel.SetSizer(main_sizer)
        
        # Events
        self.bind_events()
        
    def bind_events(self):
        """Bind UI events"""
        self.send_btn.Bind(wx.EVT_BUTTON, self.on_send)
        self.analyze_btn.Bind(wx.EVT_BUTTON, self.on_analyze)
        self.clear_btn.Bind(wx.EVT_BUTTON, self.on_clear)
        self.context_btn.Bind(wx.EVT_BUTTON, self.on_show_context)
        self.input_ctrl.Bind(wx.EVT_TEXT_ENTER, self.on_send)
        self.Bind(wx.EVT_CLOSE, self.on_close)
        
    def add_message(self, sender, message):
        """Voeg bericht toe aan chat"""
        timestamp = wx.DateTime.Now().Format("%H:%M")
        formatted_msg = f"[{timestamp}] {sender}:\n{message}\n\n"
        self.chat_ctrl.AppendText(formatted_msg)
        
    def set_status(self, status):
        """Update status tekst"""
        self.status_text.SetLabel(status)
        
    def on_send(self, event):
        """Verstuur gebruiker bericht"""
        message = self.input_ctrl.GetValue().strip()
        if not message:
            return
            
        # Voeg bericht toe
        self.add_message("🟢 You", message)
        self.input_ctrl.Clear()
        
        # Verstuur naar AI
        self.process_user_message(message)
        
    def on_analyze(self, event):
        """Analyseer huidige PCB"""
        self.set_status("Analyzing...")
        self.analyze_btn.Enable(False)
        
        # Start analyse in thread
        thread = threading.Thread(target=self.analyze_pcb)
        thread.daemon = True
        thread.start()
        
    def on_clear(self, event):
        """Wis chat geschiedenis"""
        self.chat_ctrl.Clear()
        self.conversation_history.clear()  # Wis ook conversatie geschiedenis
        self.add_message("🤖 KIC-AI", "Chat cleared. How can I help you?")
        
    def on_show_context(self, event):
        """Toon huidige conversatie context"""
        if not self.conversation_history:
            self.add_message("ℹ️ Context", "No conversation history yet.")
            return
            
        context_info = f"📝 Memory: {len(self.conversation_history)//2} exchanges remembered\n\n"
        
        # Toon laatste 4 berichten (2 exchanges)
        recent_history = self.conversation_history[-4:] if len(self.conversation_history) > 4 else self.conversation_history
        
        for entry in recent_history:
            role_emoji = "🟢" if entry['role'] == "User" else "🤖"
            content = entry['content'][:150] + "..." if len(entry['content']) > 150 else entry['content']
            context_info += f"{role_emoji} {content}\n\n"
            
        if len(self.conversation_history) > 4:
            context_info += f"(+ {len(self.conversation_history)//2 - 2} older exchanges in memory)"
            
        self.add_message("ℹ️ Context", context_info)
        
    def on_close(self, event):
        """Sluit dialog"""
        self.Destroy()
        
    def analyze_pcb(self):
        """Analyseer PCB in background thread"""
        try:
            # Krijg PCB board
            board = pcbnew.GetBoard()
            if not board:
                wx.CallAfter(self.add_message, "❌ Error", "No PCB loaded")
                return
                
            # Verzamel PCB info
            analysis = self.collect_pcb_info(board)
            
            # Toon analyse
            wx.CallAfter(self.add_message, "📊 PCB Analysis", analysis)
            
            # Stuur naar AI voor advies
            ai_prompt = f"Analyze this PCB and provide design advice:\n\n{analysis}"
            self.send_to_ai(ai_prompt, is_analysis=True)
            
        except Exception as e:
            wx.CallAfter(self.add_message, "❌ Error", f"Analysis error: {str(e)}")
        finally:
            wx.CallAfter(self.analyze_btn.Enable, True)
            wx.CallAfter(self.set_status, "Ready")
            
    def collect_pcb_info(self, board):
        """Verzamel PCB informatie"""
        info = []
        
        # Board info
        title = board.GetTitleBlock().GetTitle()
        info.append(f"PCB: {title if title else 'Unknown'}")
        
        # Afmetingen
        bbox = board.GetBoardEdgesBoundingBox()
        width_mm = bbox.GetWidth() / 1000000.0
        height_mm = bbox.GetHeight() / 1000000.0
        info.append(f"Dimensions: {width_mm:.1f} x {height_mm:.1f} mm")
        
        # Componenten
        footprints = list(board.GetFootprints())
        info.append(f"Components: {len(footprints)}")
        
        # Component types
        if footprints:
            comp_types = {}
            for fp in footprints[:10]:  # Eerste 10
                ref = fp.GetReference()
                value = fp.GetValue()
                comp_type = ref[0] if ref else "?"
                comp_types[comp_type] = comp_types.get(comp_type, 0) + 1
                
            info.append("Component types:")
            for comp_type, count in sorted(comp_types.items()):
                info.append(f"  {comp_type}: {count}")
        
        # Nets
        nets = board.GetNetInfo()
        net_count = nets.GetNetCount()
        info.append(f"Nets: {net_count}")
        
        # Tracks
        tracks = list(board.GetTracks())
        info.append(f"Tracks: {len(tracks)}")
        
        # Layers
        layer_count = board.GetCopperLayerCount()
        info.append(f"Copper layers: {layer_count}")
        
        return "\n".join(info)
        
    def process_user_message(self, message):
        """Verwerk gebruiker bericht"""
        self.set_status("AI thinking...")
        self.send_btn.Enable(False)
        
        # Start AI processing in thread
        thread = threading.Thread(target=self.send_to_ai, args=(message,))
        thread.daemon = True
        thread.start()
        
    def send_to_ai(self, message, is_analysis=False):
        """Stuur bericht naar AI (Ollama)"""
        if not REQUESTS_AVAILABLE:
            wx.CallAfter(self.add_message, "❌ Error", "Requests module not available")
            wx.CallAfter(self.send_btn.Enable, True)
            wx.CallAfter(self.set_status, "Ready")
            return
            
        try:
            # Ollama API endpoint
            url = "http://localhost:11434/api/generate"
            
            # Build simple conversation context
            conversation_context = ""
            if self.conversation_history:
                # Include last 4 exchanges (8 messages) for context
                recent_messages = self.conversation_history[-8:]
                conversation_context = "\n\nRecent conversation:\n"
                for msg in recent_messages:
                    conversation_context += f"{msg['role']}: {msg['content'][:200]}...\n"
                conversation_context += "\n"
            
            # Prepare system prompt
            if is_analysis:
                system_prompt = ("You are an expert PCB design engineer. Analyze the PCB data and provide specific, practical advice. "
                               "Reference previous conversation if relevant.")
            else:
                system_prompt = ("You are a helpful PCB design assistant. Give practical, concise answers. "
                               "Remember our conversation and build upon previous topics when relevant.")
            
            # Build final prompt
            final_prompt = system_prompt + conversation_context + f"\nCurrent question: {message}\n\nResponse:"
            
            # API request
            data = {
                "model": "llama3.2:3b",
                "prompt": final_prompt,
                "stream": False,
                "options": {
                    "temperature": 0.6,
                    "top_p": 0.9,
                    "num_ctx": 2048,
                    "repeat_penalty": 1.1
                }
            }
            
            response = requests.post(url, json=data, timeout=45)
            
            if response.status_code == 200:
                result = response.json()
                ai_response = result.get('response', 'No response received').strip()
                
                # Add to conversation history
                self.conversation_history.append({"role": "User", "content": message})
                self.conversation_history.append({"role": "Assistant", "content": ai_response})
                
                # Keep only last 12 messages (6 exchanges)
                if len(self.conversation_history) > 12:
                    self.conversation_history = self.conversation_history[-12:]
                
                wx.CallAfter(self.add_message, "🤖 KIC-AI", ai_response)
            else:
                wx.CallAfter(self.add_message, "❌ Error", f"AI server error: {response.status_code}")
                
        except requests.exceptions.ConnectionError:
            wx.CallAfter(self.add_message, "❌ Error", 
                        "Cannot connect to Ollama.\n"
                        "Start Ollama server:\n"
                        "  ollama serve\n"
                        "  ollama run llama3.2:3b")
        except requests.exceptions.Timeout:
            wx.CallAfter(self.add_message, "❌ Error", "AI timeout - please try again")
        except Exception as e:
            wx.CallAfter(self.add_message, "❌ Error", f"AI error: {str(e)}")
        finally:
            wx.CallAfter(self.send_btn.Enable, True)
            wx.CallAfter(self.set_status, "Ready")
