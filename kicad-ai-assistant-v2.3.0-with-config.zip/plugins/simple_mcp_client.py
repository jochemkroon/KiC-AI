"""
Simple MCP Client for Nexar API integration
"""

import json
import subprocess
import os
import sys

class SimpleMCPClient:
    def __init__(self):
        self.process = None
        self.request_id = 1
    
    def start_nexar_server(self):
        """Start the Nexar MCP server"""
        try:
            # Find the MCP server - try multiple possible paths
            possible_paths = [
                # First try: server in same directory as plugin (most reliable)
                os.path.join(os.path.dirname(__file__), 'nexar_server.py'),
                # Second try: original location relative to plugin
                os.path.join(os.path.dirname(os.path.dirname(__file__)), 'mcp_servers', 'nexar.py'),
                # Third try: if running from project root
                os.path.join(os.path.dirname(__file__), '..', 'mcp_servers', 'nexar.py'),
                # Fourth try: relative to current working directory
                os.path.join('mcp_servers', 'nexar.py'),
                # Fifth try: original server in mcp_servers directory
                os.path.join(os.path.dirname(os.path.dirname(__file__)), 'mcp_servers', 'nexar.py'),
                # Sixth try: embedded server as last resort
                os.path.join(os.path.dirname(__file__), 'embedded_nexar.py')
            ]
            
            server_path = None
            for path in possible_paths:
                abs_path = os.path.abspath(path)
                if os.path.exists(abs_path):
                    server_path = abs_path
                    print(f"Found Nexar server at: {server_path}")
                    break
            
            if not server_path:
                print(f"Nexar server not found. Tried paths:")
                for path in possible_paths:
                    print(f"  - {os.path.abspath(path)} {'✓' if os.path.exists(os.path.abspath(path)) else '✗'}")
                print(f"Current working directory: {os.getcwd()}")
                print(f"Plugin file location: {__file__}")
                return False
            
            # Try to start the server process - try python3 first, then python
            python_commands = ['python3', 'python']
            
            for python_cmd in python_commands:
                try:
                    self.server_process = subprocess.Popen(
                        [python_cmd, server_path],
                        stdin=subprocess.PIPE,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True,
                        bufsize=0
                    )
                    
                    print(f"Started server with {python_cmd}")
                    break
                    
                except FileNotFoundError:
                    print(f"{python_cmd} not found, trying next...")
                    continue
                    
            else:
                print("Neither python3 nor python found!")
                return False
            
            # Initialize server
            init_request = {
                "jsonrpc": "2.0",
                "id": self.request_id,
                "method": "initialize",
                "params": {}
            }
            self.request_id += 1
            
            print(f"Sending initialize request: {init_request}")
            response = self._send_request(init_request)
            print(f"Initialize response: {response}")
            
            if response and "result" in response:
                print("✅ Server initialized successfully")
                return True
            else:
                print("❌ Server initialization failed")
                if self.server_process.stderr:
                    stderr_output = self.server_process.stderr.read()
                    print(f"Server stderr: {stderr_output}")
                return False
                
        except Exception as e:
            print(f"Error starting Nexar server: {e}", file=sys.stderr)
            return False
    
    def search_parts(self, query, limit=5):
        """Search for parts using the MCP server"""
        request = {
            "jsonrpc": "2.0",
            "id": self.request_id,
            "method": "tools/call",
            "params": {
                "name": "search_parts",
                "arguments": {
                    "query": query,
                    "limit": limit
                }
            }
        }
        self.request_id += 1
        
        response = self._send_request(request)
        if response and "result" in response:
            # Extract parts from the _meta field
            meta = response["result"].get("_meta", {})
            return meta.get("parts", [])
        
        return []
    
    def get_pricing(self, part_number, quantity=1):
        """Get pricing for a specific part"""
        if not self.server_process:
            return {"error": "Server not started"}
        
        request = {
            "jsonrpc": "2.0",
            "id": self.request_id,
            "method": "tools/call",
            "params": {
                "name": "get_pricing",
                "arguments": {
                    "part_number": part_number,
                    "quantity": quantity
                }
            }
        }
        self.request_id += 1
        
        return self._send_request(request)
    
    def _send_request(self, request):
        """Send request to MCP server"""
        try:
            if not self.server_process:
                return {"error": "No server process"}
            
            # Send request
            request_json = json.dumps(request) + "\n"
            self.server_process.stdin.write(request_json)
            self.server_process.stdin.flush()
            
            # Read response
            response_line = self.server_process.stdout.readline()
            if response_line:
                return json.loads(response_line.strip())
            else:
                return {"error": "No response from server"}
                
        except Exception as e:
            return {"error": f"Request failed: {str(e)}"}
    
    def stop_server(self):
        """Stop the MCP server"""
        if self.server_process:
            self.server_process.terminate()
            self.server_process.wait(timeout=5)
            self.server_process = None
