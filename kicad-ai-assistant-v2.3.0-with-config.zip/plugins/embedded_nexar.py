#!/usr/bin/env python3
"""
Embedded Nexar Server Code
This is a fallback when the separate server file cannot be found
"""

EMBEDDED_NEXAR_SERVER = '''#!/usr/bin/env python3
"""
Embedded Nexar API MCP Server
"""

import json
import sys
import logging

logging.basicConfig(level=logging.ERROR)
logger = logging.getLogger(__name__)

class EmbeddedNexarServer:
    def __init__(self):
        self.capabilities = {
            "tools": [
                {
                    "name": "search_parts",
                    "description": "Search for electronic components and get pricing",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "query": {"type": "string", "description": "Component search query"},
                            "limit": {"type": "integer", "description": "Max results", "default": 5}
                        },
                        "required": ["query"]
                    }
                }
            ]
        }
        
    def handle_initialize(self, params):
        return {
            "protocolVersion": "2024-11-05",
            "capabilities": self.capabilities,
            "serverInfo": {"name": "embedded-nexar-server", "version": "1.0.0"}
        }
        
    def handle_list_tools(self, params):
        return {"tools": self.capabilities["tools"]}
        
    def handle_call_tool(self, params):
        tool_name = params.get("name")
        arguments = params.get("arguments", {})
        
        if tool_name == "search_parts":
            return self._search_parts(arguments)
        else:
            raise ValueError(f"Unknown tool: {tool_name}")
            
    def _search_parts(self, args):
        query = args.get("query", "")
        limit = args.get("limit", 5)
        
        # Demo parts for embedded mode
        demo_parts = [
            {
                "part_number": "STM32F407VGT6",
                "manufacturer": "STMicroelectronics",
                "description": "ARM Cortex-M4 MCU",
                "pricing": {
                    "Digi-Key": {"price_1": 8.45, "stock": 2547},
                    "Mouser": {"price_1": 8.52, "stock": 1834}
                }
            },
            {
                "part_number": "ESP32-WROOM-32E",
                "manufacturer": "Espressif",
                "description": "WiFi+BT Module",
                "pricing": {
                    "Digi-Key": {"price_1": 3.45, "stock": 5670},
                    "Mouser": {"price_1": 3.52, "stock": 4123}
                }
            }
        ]
        
        # Simple search
        results = []
        query_lower = query.lower()
        
        for part in demo_parts:
            if (query_lower in part["part_number"].lower() or 
                query_lower in part["description"].lower()):
                results.append(part)
                if len(results) >= limit:
                    break
        
        return {
            "content": [{"type": "text", "text": f"Found {len(results)} parts (embedded mode)"}],
            "isError": False,
            "_meta": {"parts": results}
        }
        
    def run(self):
        while True:
            try:
                line = sys.stdin.readline()
                if not line:
                    break
                    
                request = json.loads(line.strip())
                method = request.get("method")
                params = request.get("params", {})
                request_id = request.get("id")
                
                if method == "initialize":
                    result = self.handle_initialize(params)
                elif method == "tools/list":
                    result = self.handle_list_tools(params)
                elif method == "tools/call":
                    result = self.handle_call_tool(params)
                else:
                    raise ValueError(f"Unknown method: {method}")
                
                response = {"jsonrpc": "2.0", "id": request_id, "result": result}
                print(json.dumps(response))
                sys.stdout.flush()
                
            except Exception as e:
                error_response = {
                    "jsonrpc": "2.0",
                    "id": request.get("id") if 'request' in locals() else None,
                    "error": {"code": -32603, "message": str(e)}
                }
                print(json.dumps(error_response))
                sys.stdout.flush()

if __name__ == "__main__":
    server = EmbeddedNexarServer()
    server.run()
'''

def run_embedded_server():
    """Run the embedded server code"""
    exec(EMBEDDED_NEXAR_SERVER)

if __name__ == "__main__":
    run_embedded_server()
