# KiCad AI Assistant with Nexar API

**Real-time component pricing from multiple distributors in one call!**

## 🚀 Features
- **Multi-distributor pricing**: Digi-Key, Mouser, Farnell, Newark, Arrow, etc.
- **FREE tier**: 1,000 API calls/month (no credit card required)
- **Demo mode**: Works immediately without API token
- **AI design assistance**: Smart component suggestions and optimizations
- **Multilingual**: 6 languages supported

## 📦 Installation
1. Extract this ZIP to your KiCad plugins directory:
   - **Windows**: `%USERPROFILE%\Documents\KiCad\scripting\plugins\`
   - **macOS**: `~/Documents/KiCad/scripting/plugins/`
   - **Linux**: `~/.kicad_plugins/`

2. Restart KiCad

3. Access via: Tools → AI Assistant

## 🔑 Optional: Get Free API Access
1. Visit: https://portal.nexar.com
2. Create free account (1K calls/month)
3. Create app and get API token
4. Set environment: `export NEXAR_TOKEN="your_token"`

## 💡 Usage
- **Demo Mode**: Works immediately with realistic pricing data
- **Real API**: Set NEXAR_TOKEN for live multi-distributor pricing
- **Ask questions**: "What's the cheapest 10k resistor?" or "Find alternatives for this capacitor"

## 🆘 Support
For setup help, see the full documentation in the GitHub repository.

---
**Version 2.0.0** - Simplified with Nexar API integration
