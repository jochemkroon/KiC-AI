# Chang## [1.1.2] - 2025-07-30

### Added
- Robot icon for better toolbar appearance
- Detailed component analysis with specific component information
- Enhanced AI context with full PCB data for every user question
- Specific component lookup capabilities (e.g., asking about "R1" or specific resistors)

### Improved
- AI now provides specific answers referencing actual component values and positions
- Better PCB context integration for targeted component questions
- Increased context window for more detailed analysis
- Enhanced conversation memory with PCB awareness

### Fixed
- Plugin icon now displays properly in KiCad toolbar
- AI responses now reference specific components instead of giving generic answers

## [1.1.1] - 2025-07-30log

All notable changes to the KIC-AI Assistant plugin will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] - 2025-07-30

### Added
- **Conversation Memory**: AI now remembers previous messages in the conversation
- **Context Management**: Maintains last 20 messages for contextual responses
- **Show Context Button**: View what the AI remembers from your conversation
- **Improved Prompting**: Enhanced system prompts for better context awareness
- **Larger Context Window**: Increased to 4096 tokens for longer conversations

### Changed
- **Enhanced AI Responses**: AI can now reference previous questions and build upon earlier discussions
- **Better Context Handling**: PCB analysis results are included in conversation context
- **Improved Welcome Message**: Updated to explain conversation memory feature

### Fixed
- **Conversation Continuity**: AI no longer treats each message as isolated
- **Memory Management**: Automatic cleanup of old messages to prevent memory issues

## [1.0.0] - 2025-07-29

### Added
- Initial release of KIC-AI Assistant
- AI-powered chat interface for PCB design assistance
- Automatic PCB analysis functionality
- Ollama integration with llama3.2:3b model
- Real-time design advice and suggestions
- English interface with larger, readable fonts
- Support for KiCad 6.0+
- Component analysis and statistics
- Net and track information display
- Board dimension reporting
- Design best practices recommendations

### Features
- **Chat Interface**: Interactive dialog for asking PCB design questions
- **PCB Analysis**: Click-button analysis of current PCB design
- **AI Responses**: Context-aware responses using local LLM
- **Privacy-First**: All AI processing happens locally via Ollama
- **User-Friendly**: Large fonts and clear English interface

### Requirements
- KiCad 6.0 or higher
- Python 3.7+
- Ollama with llama3.2:3b model
- requests Python package

### Installation
- Plugin installable via KiCad Plugin and Content Manager
- Also supports manual installation
